import random
from flask import Flask, request
from pymessenger.bot import Bot

app = Flask(__name__)

ACCESS_TOKEN = 'EAAISeVoE4ssBPBhknhZA6HNcRnU8f7Xohzdp5b1xzAQFA6XZCUkY62xKdI1ZBf1pcactTkrZCkGg5Wo9C8jWY4kciCQHu9j98rstHVhLNU46DYGjc9HkpRGBY4cvkjufzyNZA2WPGDBIp0LK7eW1sYL9z4Iqg2F2NmDrkN3UBdkw9biVKFtCms0FtSHSjxbMHDkKLRJ4neO4O1RUkvlxmBFsNyyiILOBynYjJ3QZDZD'
VERIFY_TOKEN = 'myfbverify123'

bot = Bot(ACCESS_TOKEN)

@app.route('/', methods=['GET', 'POST'])
def receive_message():
    if request.method == 'GET':
        token_sent = request.args.get("hub.verify_token")
        return verify_fb_token(token_sent)
    else:
        output = request.get_json()
        for event in output.get('entry', []):
            for message in event.get('messaging', []):
                if message.get('message'):
                    sender_id = message['sender']['id']
                    if message['message'].get('text'):
                        send_message(sender_id, get_message())
                    elif message['message'].get('attachments'):
                        send_message(sender_id, get_message())
        return "Message Processed", 200

def verify_fb_token(token_sent):
    if token_sent == VERIFY_TOKEN:
        return request.args.get("hub.challenge")
    return 'Invalid verification token', 403

def get_message():
    responses = ["You are stunning!", "We're proud of you.", "Keep on being you!", "We're grateful to know you :)"]
    return random.choice(responses)

def send_message(recipient_id, response):
    bot.send_text_message(recipient_id, response)
    return "success"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)

